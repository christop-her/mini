package com.health_toc_app.health_toc_app.healthtoc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
