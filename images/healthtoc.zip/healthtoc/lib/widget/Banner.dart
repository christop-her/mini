import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class banner extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 1),
      child: Container(
        child: Row(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(21, 5, 5, 5),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.16,
                decoration: BoxDecoration(
                  color: Color.fromARGB(153, 236, 232, 232),
                  borderRadius: BorderRadius.circular(15),
                ),
                child:
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(19, 3, 1, 13),
                    child:
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      SizedBox(
                        height: 25,
                      ),
                      Text(
                        "Quick access to our\nConsultant",
                        style: GoogleFonts.poppins(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Colors.black87),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      GestureDetector(
                        child: Container(
                          height: MediaQuery.of(context).size.height * 0.0291,
                          width: MediaQuery.of(context).size.width * 0.21,
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(11),
                          ),
                          child:
                          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Text(
                              "Emergency",
                              style: GoogleFonts.poppins(
                                  fontSize: 11, color: Colors.white),
                            ),
                          ]),
                        ),
                      )
                    ]),
                  ),
                  Container(
                      height: MediaQuery.of(context).size.height * 0.5,
                      width: MediaQuery.of(context).size.width * 0.3,
                      alignment: Alignment.bottomCenter,
                      child: Image.asset("lib/icons/female.png"))
                ]),
              ),
            ),
            
            Icon(Icons.arrow_forward_ios,color: Colors.grey,size: 24,)
          ],
        ),
      ),
    );
  }
}
