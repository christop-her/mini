import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class ourservices extends StatelessWidget {
  final String MyIcon;
  final String text;

  ourservices({required this.MyIcon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(4),
      child: Row(
       // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Column(
            children: [

              Stack(
                children: [

                  Container(
                    child:  Padding(
                      padding: const EdgeInsets.fromLTRB(3, 5, 1, 1),
                      child: Column(

                        children: [
                          SizedBox(
                            height: 22,
                          ),
                          Container(
                              height: 44,
                              width: 44,
                              child: Image(image:  AssetImage(MyIcon),)),
                          SizedBox(
                            height: 69,
                          ),
                          Center(
                            child: Text(
                              text,
                              style: GoogleFonts.inter(fontSize: 13.1, color: Colors.grey),
                            ),
                          ),
                          SizedBox(
                            height: 3,
                          ),

                        ],
                      ),
                    ),
                    height: MediaQuery.of(context).size.height * 0.25,
                    width: MediaQuery.of(context).size.width * 0.28,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.black,width: 0.1),
                        boxShadow: const [
                          BoxShadow(
                              blurRadius: 10,
                              spreadRadius: 1,
                              color: Color.fromARGB(135, 238, 236, 236))
                        ],
                       ),
                  ),
                  Container(
                    height: MediaQuery.of(context).size.height * 0.18,
                    width: MediaQuery.of(context).size.width * 0.24,
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(

                        height: MediaQuery.of(context).size.height * 0.03,
                        width: MediaQuery.of(context).size.width * 0.24,
                        child:
                        Row(

                            children: [
                              SizedBox(width: 4,),
                          Icon(Icons.person,color: Colors.black,size: 14,),
                          Container(

                            child: Center(
                              child: Text(
                               '1K',
                                style: GoogleFonts.poppins(
                                    fontSize: 11,
                                    color: Colors.blue.shade700,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                          SizedBox(width: 12,),

                          Text(
                        'more',
                            style: GoogleFonts.poppins(
                                fontSize: 11,
                                color: Colors.grey,
                                ),
                          ),
                        ]),
                      ),
                    ),
                  ),
                ],
              ),


            ],
          ),
        ],
      ),
    );
  }
}
