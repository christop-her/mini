import 'dart:convert';

import 'package:healthtoc/Models/Chats.dart';
import 'package:healthtoc/Models/Top%20dotors.dart';
import 'package:http/http.dart'as http;
class DashboardApi{

  Future<List<Chat>> GetChat() async
  {
    List<Chat> Chats = [];

    try
    {
      final res =await http.post(Uri.parse('url'));

      if(res.statusCode == 200)
      {
        var responseBodyOfTrending = jsonDecode(res.body);
        if(responseBodyOfTrending["success"] == true)
        {
          (responseBodyOfTrending["chats"] as List).forEach((eachRecord)
          {
            Chats.add(Chat.fromJson(eachRecord));
          });
        }
      }
      else
      {
        // Fluttertoast.showToast(msg: "Error, status code is not 200");
      }
    }
    catch(errorMsg)
    {
      print("Error:: " + errorMsg.toString());
    }

    return Chats;
  }

}