import 'dart:convert';
import 'package:http/http.dart'as http;
import 'package:flutter/cupertino.dart';
import 'package:healthtoc/Models/Health%20articles.dart';
import 'package:healthtoc/Models/Top%20dotors.dart';

import '../Models/Banner.dart';

class BannerApi{

  Future<List<HealthArticles>> TopHealthAticle() async
  {
    List<HealthArticles> firsthealth = [];

    try
    {
      final res = await http.post(Uri.parse('url'));

      if(res.statusCode == 200)
      {
        var responseBodyOfTrending = jsonDecode(res.body);
        if(responseBodyOfTrending["success"] == true)
        {
          (responseBodyOfTrending["TopDoctors"] as List).forEach((eachRecord)
          {
            firsthealth.add(HealthArticles.fromJson(eachRecord));
          });
        }
      }
      else
      {
        // Fluttertoast.showToast(msg: "Error, status code is not 200");
      }
    }
    catch(errorMsg)
    {
      print("Error:: " + errorMsg.toString());
    }

    return firsthealth;
  }

}