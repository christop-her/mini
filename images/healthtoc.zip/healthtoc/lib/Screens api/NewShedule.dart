import 'dart:convert';

import 'package:healthtoc/Models/NewSchedules.dart';
import 'package:healthtoc/Models/Top%20dotors.dart';
import 'package:http/http.dart'as http;
class
NewShedules{

  Future<List<Newschedules>> getNewShedules() async
  {
    List<Newschedules> NewShedule = [];

    try
    {
      final res =await http.post(Uri.parse('url'));

      if(res.statusCode == 200)
      {
        var responseBodyOfTrending = jsonDecode(res.body);
        if(responseBodyOfTrending["success"] == true)
        {
          (responseBodyOfTrending["TopDoctors"] as List).forEach((eachRecord)
          {
            NewShedule.add(Newschedules.fromJson(eachRecord));
          });
        }
      }
      else
      {
        // Fluttertoast.showToast(msg: "Error, status code is not 200");
      }
    }
    catch(errorMsg)
    {
      print("Error:: " + errorMsg.toString());
    }

    return NewShedule;
  }

}