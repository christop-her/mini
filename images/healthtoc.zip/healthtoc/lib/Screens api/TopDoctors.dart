import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:healthtoc/Models/Top%20dotors.dart';
import 'package:http/http.dart'as http;
class MyTopDoctors with ChangeNotifier {

  Future<List<TopDoctors>> getTrendingProperytiesItems() async
  {
    List<TopDoctors> TopDocstors = [];

    try
    {
      final res =await http.post(Uri.parse('url'));

      if(res.statusCode == 200)
      {
        var responseBodyOfTrending = jsonDecode(res.body);
        if(responseBodyOfTrending["success"] == true)
        {
          (responseBodyOfTrending["TopDoctors"] as List).forEach((eachRecord)
          {
            TopDocstors.add(TopDoctors.fromJson(eachRecord));
          });
        }
      }
      else
      {
       // Fluttertoast.showToast(msg: "Error, status code is not 200");
      }
    }
    catch(errorMsg)
    {
      print("Error:: " + errorMsg.toString());
    }

    return TopDocstors;
  }

 }