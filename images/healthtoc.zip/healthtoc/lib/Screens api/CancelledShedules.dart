import 'dart:convert';

import 'package:healthtoc/Models/NewSchedules.dart';
import 'package:healthtoc/Models/Top%20dotors.dart';
import 'package:http/http.dart'as http;

import '../Models/CancelledSchedules.dart';
class
  cancelledshedules{

  Future<List<Cancelledschedules>> getCancelledShedules() async
  {
    List<Cancelledschedules> CancelledShedulelist = [];

    try
    {
      final res =await http.post(Uri.parse('url'));

      if(res.statusCode == 200)
      {
        var responseBodyOfTrending = jsonDecode(res.body);
        if(responseBodyOfTrending["success"] == true)
        {
          (responseBodyOfTrending["TopDoctors"] as List).forEach((eachRecord)
          {
            CancelledShedulelist.add(Cancelledschedules.fromJson(eachRecord));
          });
        }
      }
      else
      {
        // Fluttertoast.showToast(msg: "Error, status code is not 200");
      }
    }
    catch(errorMsg)
    {
      print("Error:: " + errorMsg.toString());
    }

    return  CancelledShedulelist;
  }

}