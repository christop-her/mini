import 'dart:convert';
import 'package:healthtoc/Models/MessageScreen.dart';
import 'package:healthtoc/Models/MessageScreen.dart';
import 'package:http/http.dart'as http;

import 'package:flutter/cupertino.dart';
import 'package:healthtoc/Models/Top%20dotors.dart';

import '../Models/Banner.dart';

class Messagescreen{

  Future<List<Banners>> fetchBanners() async {
    final response = await http.post(
      Uri.parse('http://ailemen.42web.io/get_banners.php'),
    );

    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((banner) => Banners.fromJson(banner)).toList();
    } else {
      throw Exception('Failed to load banners');
    }
  }

  Future<List<MessageScreenone>> MessageScreen() async
  {
    List<MessageScreenone> Messagescreens = [];

    try
    {
      final response =await  http.post(Uri.parse('http://ailemen.42web.io/get_banners.php'));

      if(response.statusCode == 200)
      {
        var responseBodyOfTrending = jsonDecode(response.body);
        if(responseBodyOfTrending["success"] == true)
        { print('yesssss');
        (responseBodyOfTrending["TopDoctors"] as List).forEach((eachRecord)
        {
          Messagescreens.add(MessageScreenone.fromJson(eachRecord));
        });
        }
      }
      else
      {
        print('yesssss');
        // Fluttertoast.showToast(msg: "Error, status code is not 200");
      }
    }
    catch(errorMsg)
    {
      print("Error:: " + errorMsg.toString());
    }

    return Messagescreens;
  }

}