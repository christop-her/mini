class MessageScreenone{
  String? content;
  String? time;
  String? header;
  String? image;

  MessageScreenone({
    this.header,
    this.content,
    this.image,
    this.time,

  });

  factory MessageScreenone.fromJson(Map<String, dynamic> json) =>MessageScreenone(
    content: json['content'],
    time: json['time'],
    header: json['header'],
    image: json['image'],
  );
}