class HealthArticles{
  String? content;
  String? link;
  String? header;
  String? image;

  HealthArticles({
    this.header,
    this.content,
    this.image,
    this.link,

  });

  factory HealthArticles.fromJson(Map<String, dynamic> json) =>HealthArticles(
    content: json['content'],
    link: json['link'],
    header: json['header'],
    image: json['image'],
  );
}