import 'package:flutter/cupertino.dart';

class TopDoctors  {
String? doctor_id;
String? doctor_email;
String?doctor_name;
double? rating;
String? description;
int? location;
String? image;

TopDoctors({
this.doctor_email,
this.location,
this.doctor_name,
this.doctor_id,
this.description,
this.image,
this.rating,

});

factory TopDoctors.fromJson(Map<String, dynamic> json) => TopDoctors(
location: int.parse(json['location']),
doctor_email: json['doctor_email'],
doctor_id: json['doctor_id'],
doctor_name: json['doctor_name'],
rating: double.parse(json['rating']),
description: json['description'],
image: json['image'],
);
}