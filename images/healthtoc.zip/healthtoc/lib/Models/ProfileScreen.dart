class MyProfile{
  String? name;
  String? email;
  String? username;
  String? time;
  String? status;
  String? header;
  String? image;

  MyProfile({
    this.header,
    this.email,
    this.image,
    this.time,
    this.name,
    this.username,
    this.status,

  });

  factory MyProfile.fromJson(Map<String, dynamic> json) =>MyProfile(
    time: json['time'],
        email: json['email'],
    header: json['header'],
    image: json['image'],
    status: json['status'],
    username: json['username'],
    name: json['name'],
  );
}