class Newschedules{
  String? name;
  String? title;
  String? date;
  String? time;
  String? status;
  String? header;
  String? image;

  Newschedules({
    this.header,
    this.title,
    this.image,
    this.time,
  this.name,
  this.date,
  this.status,

  });

  factory Newschedules.fromJson(Map<String, dynamic> json) =>Newschedules(
    time: json['time'],
    title: json['title'],
    header: json['header'],
    image: json['image'],
    status: json['status'],
    date: json['date'],
    name: json['name'],
  );
}