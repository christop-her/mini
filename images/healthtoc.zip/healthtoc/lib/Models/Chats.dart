class Chat{
  String? content;
  String? link;
  String? user;
  String? image;
  String? time;
  Chat({
    this.time,
    this.content,
    this.image,
    this.link,
    this.user,

  });

  factory Chat.fromJson(Map<String, dynamic> json) =>Chat(
    content: json['content'],
    link: json['link'],
    user: json['user'],
    image: json['image'],
    time: json['time'],
  );
}