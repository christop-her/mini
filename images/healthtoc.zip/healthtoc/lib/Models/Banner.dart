class Banners{
  String? content;
  String? link;
  String? header;
  String? image;

  Banners({
    this.header,
    this.content,
    this.image,
    this.link,

  });

  factory Banners.fromJson(Map<String, dynamic> json) =>Banners(
    content: json['content'],
    link: json['link'],
    header: json['header'],
    image: json['image'],
  );
}