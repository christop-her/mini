import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:healthtoc/auth/auth_service.dart';
import 'package:page_transition/page_transition.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../helper/helper_function.dart';
import 'login.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  bool _isLoading = false;
  bool _isChecked = false;
  bool _isFormValid = false;
  final formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  bool obscureText = true;
  AuthService authService = AuthService();
  Color customColor = Color(0xFF010043);


  void _showLoadingDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white, // Set background color to white
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0), // Optional: to make it a square
          ),
          content: Container(
            height: 44.0, // Adjust the height
            width: 44.0, // Adjust the width to make it a square
            child: Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF010043)),
              ),
            ),
          ),
        );
      },
    );
  }

  void _showSuccessDialog(BuildContext context,String text,String body) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white, // Set background color to white
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0), // Optional: make it a square
          ),
          content: Container(
            height: 290.0, // Adjust the height
            width: 200.0, // Adjust the width to make it a square
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.grey[200],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Icon(
                      Icons.check,
                      color: Color(0xFF010043),
                      size: 50.0, // Adjust the size if needed
                    ),
                  ),
                ),
                SizedBox(height: 20.0),
                Text(
                  'Registration $text',
                  style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,

                  ),
                ),
                SizedBox(height: 5.0),

                Text(
                  body,
                  style: TextStyle(
                    fontSize: 18.0,
                      color: Colors.grey.shade300,
                  ),
                ),
                SizedBox(height: 20.0),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF010043), // Button color
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                    Navigator.pushReplacement(
                        context, MaterialPageRoute(builder: (context) => loginpage()));
                  },
                  child: Text('Login now',
                    style: TextStyle(
                      fontSize: 18.0,
                      color: Colors.white,
                    ),),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _unSuccessDialog(BuildContext context,String text,String body) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white, // Set background color to white
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0), // Optional: make it a square
          ),
          content: Container(
            height: 290.0, // Adjust the height
            width: 200.0, // Adjust the width to make it a square
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.grey[200],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Icon(
                      Icons.check,
                      color: Color(0xFF010043),
                      size: 50.0, // Adjust the size if needed
                    ),
                  ),
                ),
                SizedBox(height: 20.0),
                Text(
                  'Registration $text',
                  style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,

                  ),
                ),
                SizedBox(height: 5.0),

                Text(
                  body,
                  style: TextStyle(
                    fontSize: 18.0,
                    color: Colors.grey.shade300,
                  ),
                ),


              ],
            ),
          ),
        );
      },
    );
  }
  Future<void> addUserToFirestore(String email, String fullName, String password) async {
    try {
      CollectionReference users = FirebaseFirestore.instance.collection('users');

      await users.doc(email.toString()).set({
        'fullName': fullName,
        'email': email,
        'password': password, // Hash passwords for security
      });

      print("User added successfully!");
    } catch (e) {
      print("Error adding user: $e");
      throw e; // Optionally rethrow to handle at the call site
    }
  }


  void _register() async {
    if (_isFormValid) {
      setState(() {
        _isLoading = true;
      });
      _showLoadingDialog(context);
      await authService
          .registerUserWithEmailandPassword(
          _fullNameController.text,
          _emailController.value.text.toString().trim(),
          _passwordController.text)
          .then((value) async {
        if (value == true) {   Navigator.of(context).pop();
          _showSuccessDialog(context,'Success','Your account has been \n successfully registerd');
          savename();
          await addUserToFirestore(
              _emailController.text,
              _fullNameController.text,
              _passwordController.text);
          await Future.delayed(Duration(seconds: 1));
          Navigator.of(context).pop();

          await HelperFunctions.saveUserLoggedInStatus(true);
          await HelperFunctions.saveUserEmailSF(_emailController.text);
          await HelperFunctions.saveUserNameSF(_fullNameController.text);
        } else {
          Navigator.of(context).pop();
          _unSuccessDialog(context,'Unsuccessful','Registration Unsuccessful');
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error registering user')));
          setState(() {
            _isLoading = false;
          });
        }
      });
    }
  }

  savename() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();


    try {
      preferences.setString(
          'mynamed',_fullNameController.text);
    } catch (e) {
      print(e.toString());
    }
  }



  void _checkFormValid() {
    setState(() {
      _isFormValid = _emailController.text.isNotEmpty &&
          _fullNameController.text.isNotEmpty &&
          _passwordController.text.length >= 8 &&
          _passwordController.text == _confirmPasswordController.text &&
          _isChecked;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        leading: IconButton(
          icon: Container(
              height: MediaQuery.of(context).size.height * 0.06,
              width: MediaQuery.of(context).size.width * 0.06,
              child: Image.asset("lib/icons/back2.png")),
          onPressed: () {
            Navigator.push(
                context,
                PageTransition(
                    type: PageTransitionType.leftToRight, child: loginpage()));
          },
        ),
        title: Text(
          "Sign up",
          style: GoogleFonts.inter(
              color: Colors.black87,
              fontSize: 22,
              fontWeight: FontWeight.w700,
              letterSpacing: 0),
        ),
        toolbarHeight: 110,
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: ListView(
          children: [
            const SizedBox(height: 40),
            _buildTextField(
              controller: _fullNameController,
              label: "Enter your name",
              icon: "lib/icons/person.png",
              onChanged: (val) => _checkFormValid(),
              validator: (val) => val!.isEmpty ? "Name cannot be blank" : null,
            ),
            const SizedBox(height: 5),
            _buildTextField(
              controller: _emailController,
              label: "Enter your email",
              icon: "lib/icons/email.png",
              onChanged: (val) => _checkFormValid(),
              validator: (val) => RegExp(
                  r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                  .hasMatch(val!)
                  ? null
                  : "Please enter a valid email",
            ),
            const SizedBox(height: 5),
            _buildTextField(
              controller: _passwordController,
              label: "Enter your password",
              icon: "lib/icons/lock.png",
              obscureText: obscureText,
              onChanged: (val) => _checkFormValid(),
              validator: (val) => val!.length < 8 ? "Password too short" : null,
              suffixIcon: IconButton(
                onPressed: () {
                  setState(() {
                    obscureText = !obscureText;
                  });
                },
                icon: Icon(
                  obscureText ? Icons.remove_red_eye : Icons.visibility_off,
                  size: 20,
                ),
              ),
            ),
            _buildTextField(
              controller: _confirmPasswordController,
              label: "Confirm password",
              icon: "lib/icons/lock.png",
              obscureText: obscureText,
              onChanged: (val) => _checkFormValid(),
              validator: (val) => val != _passwordController.text
                  ? "Passwords do not match"
                  : null,
              suffixIcon: IconButton(
                onPressed: () {
                  setState(() {
                    obscureText = !obscureText;
                  });
                },
                icon: Icon(
                  obscureText ? Icons.remove_red_eye : Icons.visibility_off,
                  size: 20,
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Checkbox(
                  value: _isChecked,
                  onChanged: (bool? value) {
                    setState(() {
                      _isChecked = value!;
                      _checkFormValid();
                    });
                  },
                  activeColor: Color(0xFF010043),
                ),
                Text(
                  "I agree to the terms and conditions",
                  style: GoogleFonts.poppins(
                    fontSize: MediaQuery.sizeOf(context).width / 27,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
            SizedBox(height: 30),
            Container(
              height: MediaQuery.of(context).size.height * 0.05,
              width: MediaQuery.of(context).size.width * 0.9,
              child: ElevatedButton(
                onPressed: _isFormValid ? _register : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: customColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: Text(
                  "Create account",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0,
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Already have an account?",
                  style: GoogleFonts.poppins(
                    fontSize: MediaQuery.sizeOf(context).width / 27,
                    color: Colors.black87,
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        PageTransition(
                            type: PageTransitionType.fade, child: loginpage()));
                  },
                  child: Text(
                    "Sign in",
                    style: GoogleFonts.poppins(
                      fontSize: MediaQuery.sizeOf(context).width / 27,
                      color: Color(0xFF010043),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }


  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String icon,
    bool obscureText = false,
    required Function(String) onChanged,
    required String? Function(String?) validator,
    Widget? suffixIcon,
  }) {
    return Center(
      child: Container(
        height: MediaQuery.of(context).size.height * 0.1,
        width: MediaQuery.of(context).size.width * 0.9,
        child: TextFormField(
          controller: controller,
          obscureText: obscureText,
          textAlign: TextAlign.start,
          textInputAction: TextInputAction.none,
          textAlignVertical: TextAlignVertical.center,
          onChanged: onChanged,
          validator: validator,
          decoration: InputDecoration(
            suffixIcon: suffixIcon,
            focusColor: Colors.black26,
            fillColor: Color.fromARGB(255, 247, 247, 247),
            filled: true,
            prefixIcon: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Image.asset(icon),
            ),
            prefixIconColor: const Color.fromARGB(255, 3, 190, 150),
            label: Text(label),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.circular(30),
            ),
            errorStyle: TextStyle(
              color: Colors.red, // Error text color
              fontSize: 12.0, // Error text size
            ),
          ),
          style: TextStyle(
            color: Colors.black, // Text color
          ),
          cursorColor: Colors.black, // Cursor color
          autovalidateMode: AutovalidateMode.onUserInteraction, // Validate on user interaction
        ),
      ),
    );
  }
}
