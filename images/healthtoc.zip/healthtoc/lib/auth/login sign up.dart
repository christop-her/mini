import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';


import 'package:page_transition/page_transition.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'Register.dart';
import 'login.dart';


class login_signup extends StatefulWidget {
  const login_signup({super.key});

  @override
  State<login_signup> createState() => _login_signupState();
}

class _login_signupState extends State<login_signup> {
  final formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";
  bool _isLoading = false;
  bool   autocorrect =true ;
  bool  obscuretext = true;




  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController myController = TextEditingController();


  String emailx ='Email';

  String passx ='password';


  exset() async {
    emailx= _emailController.text;

  }

  pxset() async {
    passx= _emailController.text;

  }


  getFromPhone() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {

      emailx=   preferences.getString('named').toString() ;
    });
    try {
      return preferences.getString('named');
    } catch (e) {
      print(e.toString());
    }
  }

  getFromPhonee() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {

      passx =   preferences.getString('nameed').toString() ;
    });
    try {
      return preferences.getString('nameed');
    } catch (e) {
      print(e.toString());
    }
  }


  saveToPhonee() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();


    try {
      preferences.setString(
          'nameed',_passwordController.text);
    } catch (e) {
      print(e.toString());
    }
  }

  saveToPhone() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    try {
      preferences.setString('named', _emailController.text,);
    } catch (e) {
      print(e.toString());
    }
  }

  void edata ()async{

    await  getFromPhone();
    await getFromPhonee();
    setState(() {
      _passwordController.text=passx.toString();
      _emailController.text=emailx.toString();
      print(passx.trim());
      print(emailx);
    });


  }
  void initState() {
    // TODO: implement initState
    super.initState();

  }
  Color customColor = Color(0xFF010043);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(children: [
        const SizedBox(
          height: 110,
        ),
        Container(
          height: MediaQuery.of(context).size.height * 0.29,
          width: MediaQuery.of(context).size.height * 019,
          decoration: const BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("images/trans.png"),
                  filterQuality: FilterQuality.high)),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Lets get Started!",
              style: GoogleFonts.poppins(
                  fontSize: 22,
                  color: Color.fromARGB(211, 14, 13, 13),
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1),
            ),
          ],
        ),
        SizedBox(
          height: 5,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Text(
                  "Login to get access to the best medical \nfeatures we have made to improve a\n healthy living",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                      fontSize: 15,
                      color: Color.fromARGB(211, 14, 13, 13),
                      fontWeight: FontWeight.w400,
                      ),
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: 50,
        ),
        Container(
          height: MediaQuery.of(context).size.height * 0.06,
          width: MediaQuery.of(context).size.width * 0.7,
          child: ElevatedButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder:(context)=>loginpage() ));
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: customColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Text(
              "Login",
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                fontSize: 18,
                color: Colors.white,
                fontWeight: FontWeight.w500,
                letterSpacing: 0,
              ),
            ),
          ),
        ),
        SizedBox(
          height: 20,
        ),
        Container(
          height: MediaQuery.of(context).size.height * 0.06,
          width: MediaQuery.of(context).size.width * 0.7,
          decoration: BoxDecoration(
              border: Border.all(color: customColor,width: .5),
              borderRadius: BorderRadius.circular(30)),
          child: ElevatedButton(
            onPressed: () {
              Navigator.push(
                  context,
                  PageTransition(
                      type: PageTransitionType.rightToLeft, child: RegisterPage()));
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Text(
              "Sign up",
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                fontSize: 18,
                color: customColor,
                fontWeight: FontWeight.w500,
                letterSpacing: 0,
              ),
            ),
          ),
        ),
      ]),
    );
  }

  login() {}
}

register() {
}

