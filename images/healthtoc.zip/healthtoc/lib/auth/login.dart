import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:healthtoc/screens/Home.dart';
import 'package:healthtoc/screens/Loading%20Screen.dart';
import 'package:healthtoc/widget/social%20login.dart';

import 'package:page_transition/page_transition.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Register.dart';
import 'auth_service.dart';
import '../widget/auth text field.dart';
import 'login sign up.dart';


class loginpage extends StatefulWidget {
  const loginpage({super.key});

  @override
  State<loginpage> createState() => _loginpageState();
}

class _loginpageState extends State<loginpage> {
  @override
  AuthService authService = AuthService();
  final formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";
  bool _isLoading = false;
  bool   autocorrect =true ;
  bool  obscuretext = true;




  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController myController = TextEditingController();


  String emailx ='Email';

  String passx ='password';


  exset() async {
    emailx= _emailController.text;

  }

  pxset() async {
    passx= _emailController.text;

  }


  getFromPhone() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {

      emailx=   preferences.getString('named').toString() ;
    });
    try {
      return preferences.getString('named');
    } catch (e) {
      print(e.toString());
    }
  }

  getFromPhonee() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {

      passx =   preferences.getString('nameed').toString() ;
    });
    try {
      return preferences.getString('nameed');
    } catch (e) {
      print(e.toString());
    }
  }


  saveToPhonee() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();


    try {
      preferences.setString(
          'nameed',_passwordController.text);
    } catch (e) {
      print(e.toString());
    }
  }

  saveToPhone() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    try {
      preferences.setString('named', _emailController.text,);
    } catch (e) {
      print(e.toString());
    }
  }

  void edata ()async{

    await  getFromPhone();
    await getFromPhonee();
    setState(() {
      _passwordController.text=passx.toString();
      _emailController.text=emailx.toString();
      print(passx.trim());
      print(emailx);
    });


  }
  void initState() {
    // TODO: implement initState
    super.initState();
    edata();
   // login();
  }

   _showLoadingDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white, // Set background color to white
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0), // Optional: to make it a square
          ),
          content: Container(
            height: 44.0, // Adjust the height
            width: 44.0, // Adjust the width to make it a square
            child: Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF010043)),
              ),
            ),
          ),
        );
      },
    );
  }



  Widget build(BuildContext context) {
    Color customColor = Color(0xFF010043);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Container(
              height: MediaQuery.of(context).size.height * 0.06,
              width: MediaQuery.of(context).size.width * 0.06,
              child: Image.asset("lib/icons/back2.png")),
          onPressed: () {
            Navigator.push(
                context,
                PageTransition(
                    type: PageTransitionType.leftToRight,
                    child: login_signup()));
          },
        ),
        centerTitle: true,
        title: Text(
          "Login",
          style: GoogleFonts.inter(
              color: Colors.black87,
              fontSize: 22,
              fontWeight: FontWeight.w700,
              letterSpacing: 0),
        ),
        toolbarHeight: 110,
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: ListView (children: [
          const SizedBox(
            height: 40,
          ),
          //Text field Login import from Auth_text_field widget
          Center(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.1,
              width: MediaQuery.of(context).size.width * 0.9,
              child: TextFormField(
                validator: (val) {
                  return RegExp(
                      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                      .hasMatch(val!)
                      ? null
                      : "Please enter a valid email";
                },
                controller:_emailController ,
                textAlign: TextAlign.start,
                textInputAction: TextInputAction.none,
                obscureText: false,
                keyboardType: TextInputType.emailAddress,
                textAlignVertical: TextAlignVertical.center,
                decoration: InputDecoration(
                    focusColor: Colors.black26,
                    fillColor: Color.fromARGB(255, 247, 247, 247),
                    filled: true,
                    prefixIcon: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                      ),
                      child: Container(
                        child: Image.asset("lib/icons/email.png"),
                      ),
                    ),
                    prefixIconColor: const Color.fromARGB(255, 3, 190, 150),
                    label: Text("Enter your email"),
                    floatingLabelBehavior: FloatingLabelBehavior.never,
                    border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(30),
                    )),
              ),
            ),
          ),
          const SizedBox(
            height: 5,
          ),
          //Text field Password
          Center(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.1,
              width: MediaQuery.of(context).size.width * 0.9,
              child: TextFormField(
                validator: (val) {
                  val!.length<9

                      ? null
                      : "Password too short";
                },
                controller:_passwordController ,
                textAlign: TextAlign.start,
                textInputAction: TextInputAction.none,
                obscureText: obscuretext?? true,
                keyboardType: TextInputType.emailAddress,
                textAlignVertical: TextAlignVertical.center,
                decoration: InputDecoration(
                    suffixIcon:  obscuretext == true
                        ? IconButton(
                        onPressed: () {
                          setState(() {
                            obscuretext = false;
                          });
                        },
                        icon: Icon(
                          Icons.remove_red_eye,
                          size: 20,
                        ))
                        : IconButton(
                        onPressed: () {
                          setState(() {
                            obscuretext = true;
                          });
                        },
                        icon: Icon(
                            Icons.visibility_off,
                            size: 20
                        )
                    ),

                    focusColor: Colors.black26,
                    fillColor: Color.fromARGB(255, 247, 247, 247),
                    filled: true,
                    prefixIcon: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                      ),
                      child: Container(
                        child: Image.asset("lib/icons/lock.png"),
                      ),
                    ),
                    prefixIconColor: const Color.fromARGB(255, 3, 190, 150),
                    label: Text("Enter your password"),
                    floatingLabelBehavior: FloatingLabelBehavior.never,
                    border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(30),
                    )),
              ),
            ),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            GestureDetector(
              onTap: () {

              },
              child: Text(
                "Forgot your password?",
                style: GoogleFonts.poppins(
                    fontSize: 15,
                    color: customColor,
                    fontWeight: FontWeight.w500),
              ),
            )
          ]),
          SizedBox(
            height: 10,
          ),
          Container(
            height: MediaQuery.of(context).size.height * 0.05,
            width: MediaQuery.of(context).size.width * 0.9,
            child: ElevatedButton(
              onPressed: () {
                _showLoadingDialog(context); // Show the loading dialog immediately
                logins(); // Perform your login action here
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: customColor, // Use your custom color here
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: Text(
                "Login",
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  color: Color.fromARGB(255, 255, 255, 255),
                  fontWeight: FontWeight.w500,
                  letterSpacing: 0,
                ),
              ),
            ),
          ),

          SizedBox(
            height: 30,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Don't have an account? ",
                style:
                GoogleFonts.poppins(fontSize: 15, color: Colors.black87),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                      context, MaterialPageRoute(builder: (context) => RegisterPage()));
                },
                child: Text(
                  "Sign Up",
                  style: GoogleFonts.poppins(
                    fontSize: 15,
                    color: customColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(child: Divider()),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  "or",
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Expanded(child: Divider()),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          auth_social_logins(
              logo: "images/google.png", text: "Sign in with Google"),
          const SizedBox(
            height: 20,
          ),
          auth_social_logins(logo: "images/apple.png", text: "Sign in Apple"),
          const SizedBox(
            height: 20,
          ),
          auth_social_logins(
              logo: "images/facebook.png", text: "Sign in facebook")
        ]),
      ),
    );
  }
  logins() async {

    if (_emailController.value.text!=null) {
      setState(() {
        _isLoading = true;
      });

      await authService
          .loginWithUserNameandPassword(_emailController.value.text.toString().trim(), _passwordController.text)
          .then((value) async {
        if (value == true) {
          Navigator.of(context).pop();
          _showSuccessDialog(context);

          saveToPhone();
          saveToPhonee();

          // saving the values to our shared preferences


        } else {
      //    showSnackbar(context, Colors.blue.shade800, value,);
          setState(() {
            _isLoading = false;
          });
        }
      });
    }
  }

  void _showSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white, // Set background color to white
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0), // Optional: to make it a square
          ),
          content: Container(
            height: 300.0, // Adjust the height
            width: 370.0, // Adjust the width to make it a square
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.grey[200],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Icon(
                      Icons.check,
                      color: Color(0xFF010043),
                      size: 50.0, // Adjust the size if needed
                    ),
                  ),
                ),
                SizedBox(height: 20.0),
                Text(
                  'Welcome Back!',
                  style: TextStyle(
                    fontSize: 19.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 5.0),
                Text(
                  'Once again you have login\n              Successfully\n        into healthtoc app',
                  style: TextStyle(
                    fontSize: 15.0,
                    color: Colors.grey.shade300,
                  ),
                ),
                SizedBox(height: 20.0),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF010043), // Button color
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                  ),
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                    Navigator.pushReplacement(
                        context, MaterialPageRoute(builder: (context) => Homepage()));
                  },
                  child: Text('Go to Home',   style: GoogleFonts.poppins(
                    fontSize: 15,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

}