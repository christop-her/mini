import 'dart:async';

import 'package:flutter/material.dart';
import '../On_Board/on_boarding.dart';


class Screen1 extends StatefulWidget {
  const Screen1({super.key});

  @override
  State<Screen1> createState() => _Screen1State();
}

class _Screen1State extends State<Screen1> {
  @override


  @override
  Widget build(BuildContext context) {
    return on_boarding();
  }
}
