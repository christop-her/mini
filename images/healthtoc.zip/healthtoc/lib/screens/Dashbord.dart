import 'dart:convert';
import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:healthtoc/Screens%20api/TopDoctors.dart';
import 'package:http/http.dart'as http;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:healthtoc/Models/Banner.dart';

import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Test/Provider Class.dart';
import '../widget/Banner.dart';
import '../widget/List icons.dart';
import '../widget/article.dart';
import '../widget/articles1.dart';
import '../widget/listIcon.dart';
import 'Doctorlist.dart';
import 'find a doctor.dart';


class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}
User? user = FirebaseAuth.instance.currentUser;
final currentUserEmail = user!.email;
class _DashboardState extends State<Dashboard> {

  @override

  Future<List<Banners>> fetchBanners() async {
    final response = await http.post(
      Uri.parse('http://ailemen.42web.io/get_banners.php'),
    );
    log('Error parsing JSON: $response');
    log('Response body: ${response.body}');

    if (response.statusCode == 200) {
      log('Error parsing JSON: $response');
      log('Response body: ${response.body}');
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((banner) => Banners.fromJson(banner)).toList();
    } else {
      throw Exception('Failed to load banners');
    }
  }
  String name ='User';
  void edata ()async{

    await  getFromPhone();

    setState(() {
      print(name.trim());

    });


  }
  getFromPhone() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {

     name =   preferences.getString('mynamed').toString() ;
    });
    try {
      return preferences.getString('mynamed');
    } catch (e) {
      print(e.toString());
    }
  }


  Future<List<Banners>> TopBanner() async
  {
    List<Banners> firstBanner = [];

    try
    {
      final response =await  http.post(Uri.parse('http://ailemen.42web.io/get_banners.php'));

      if(response.statusCode == 200)
      {
        var responseBodyOfTrending = jsonDecode(response.body);
        if(responseBodyOfTrending["success"] == true)
        { log('yesssss');
        (responseBodyOfTrending["TopDoctors"] as List).forEach((eachRecord)
        {
          firstBanner.add(Banners.fromJson(eachRecord));
        });
        }
      }
      else
      {
        log('nooo');
        // Fluttertoast.showToast(msg: "Error, status code is not 200");
      }
    }
    catch(errorMsg)
    {
      print("Error:: " + errorMsg.toString());
    }

    return firstBanner;
  }
  username() async {


    SharedPreferences prefs = await SharedPreferences.getInstance();
    final storedValue = prefs.get('user') ; // Default value is 1
    return storedValue;
  }

  @override

  Future<String?> getFieldValuecurrentballance() async {
    try {
      DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
      await FirebaseFirestore.instance.collection('users').doc(currentUserEmail.toString()).get();

      if (documentSnapshot.exists) {
        // Check if the document exists
        dynamic fieldValue = documentSnapshot.data()?['fullName'];
        if (fieldValue != null) {
          // Check if the field exists

          return fieldValue.toString();

        }
      }

      return null; // Return null if the document or field doesn't exist
    } catch (e) {
      print('Error getting field value: $e');
      return null;
    }
  }

  void initState() {
    getFromPhone();
    getFieldValuecurrentballance();
    fetchBanners();
    TopBanner();
    // TODO: implement initState
    super.initState();
  }

  Widget build(BuildContext context) {


  //  final mybanner = Provider.of<UserProvider>(context).user;
  //  final topdoctors = Provider.of<MyTopDoctors>(context).getTrendingProperytiesItems();
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Color.fromARGB(255, 255, 255, 255),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
            child: Container(
              alignment: Alignment.bottomCenter,
              height: MediaQuery.of(context).size.height * 0.1,
              width: MediaQuery.of(context).size.width * 0.06,
              child: Image.asset(
                "lib/icons/bell.png",
                filterQuality: FilterQuality.high,
              ),
            ),
          ),
        ],
        title: Column(
          children: [
            SizedBox(
              height: 10,
            ),
            Container(height: 22,width: 444,
              child: Text(
                "Hello,${name??'User'}, ",
                style: GoogleFonts.inter(
                    color: Color.fromARGB(255, 51, 47, 47),
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    ),
              ),
            ),
            SizedBox(height: 17,),
            Container(
              height: 22,width: 444,
              child: Text(
                "Explore and discover solution to your ",
                style: GoogleFonts.inter(
                    color: Color.fromARGB(255, 51, 47, 47),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    ),
              ),
            ),
            SizedBox(height: 8,),
            Container(
              height: 22,width: 444,
              child: Text(
                "health problem ",
                style: GoogleFonts.inter(
                    color: Color.fromARGB(255, 51, 47, 47),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                   ),
              ),
            ),
          ],
        ),
        toolbarHeight: 130,
        elevation: 0,
      ),
      backgroundColor: Color.fromARGB(255, 255, 255, 255),
      body: SingleChildScrollView(
        child: Column(children: [


          SizedBox(
            height: 20,
          ),
          Center(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.06,
              width: MediaQuery.of(context).size.width * 0.9,
              decoration: BoxDecoration(),
              child: TextField(
                onTap: () {
                  Navigator.push(
                      context,
                      PageTransition(
                          type: PageTransitionType.rightToLeft,
                          child: find_doctor()));
                },
                textAlign: TextAlign.start,
                textInputAction: TextInputAction.none,
                autofocus: false,
                obscureText: false,
                keyboardType: TextInputType.emailAddress,
                textAlignVertical: TextAlignVertical.center,
                decoration: InputDecoration(
                  hintText:"Search doctor, drugs, articles..." ,
                  focusColor: Colors.black26,
                  fillColor: Color.fromARGB(255, 247, 247, 247),
                  filled: true,
                  prefixIcon: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                    ),
                    child: Container(
                      height: 10,
                      width: 10,
                      child: Image.asset(
                        "lib/icons/search.png",
                        filterQuality: FilterQuality.high,
                      ),
                    ),
                  ),
                  prefixIconColor:Color(0xFF010043),
                  label: Text("Search doctor, drugs, articles..."),
                  floatingLabelBehavior: FloatingLabelBehavior.never,
                  border: OutlineInputBorder(
                    borderSide: BorderSide.none,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          //Body Start fro here

          //Body Start fro here
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap:(){
                //  fetchBanners();
                  TopBanner();
                } ,
                  child: listIcons(Icon: "images/log3.png", text: "Doctor")),
              // GestureDetector(
              //     onTap:(){} ,
              //     child: listIcons(Icon: "lib/icons/Pharmacy.png", text: "Pharmacy")),
              GestureDetector(
                  onTap:(){} ,
                  child: listIcons(Icon: "images/log2.png", text: "Hospital")),
              GestureDetector(
                  onTap:(){} ,
                  child: listIcons(Icon: "images/log1.png", text: "Donate Blood")),
            ],
          ),
          //List icons (Can Edit in Widgets )
          SizedBox(
            height: 10,),
          banner(),

          Padding(
            padding: const EdgeInsets.fromLTRB(31, 8, 28, 1),
            child: Container(
              height: MediaQuery.of(context).size.height/19,
              width: MediaQuery.of(context).size.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Medical Services",
                    style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.black87),
                  ),


                  TextButton(
                    onPressed: () {

                    },
                    child:   Text(
                      "Seee all",
                      style: GoogleFonts.poppins(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: Colors.blue),
                    ),)
                ],
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                  onTap:(){
                    //  fetchBanners();
                    TopBanner();
                  } ,
                  child: ourservices(MyIcon: "images/plu1.png", text: "Reproductive Health")),
              // GestureDetector(
              //     onTap:(){} ,
              //     child: listIcons(Icon: "lib/icons/Pharmacy.png", text: "Mental Health")),
              GestureDetector(
                  onTap:(){} ,
                  child: ourservices(MyIcon: "images/plu2.png", text: "Mental Health")),
              GestureDetector(
                  onTap:(){} ,
                  child: ourservices(MyIcon: "images/dis3.png", text: "General Clinic")),
            ],
          ),


          Padding(
            padding: const EdgeInsets.fromLTRB(31, 8, 28, 1),
            child: Container(
              height: MediaQuery.of(context).size.height/19,
              width: MediaQuery.of(context).size.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Top Doctors",
                    style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.black87),
                  ),


                  TextButton(
                    onPressed: () {

                  },
                      child:   Text(
                        "See all",
                        style: GoogleFonts.poppins(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color:Color(0xFF010043)),
                      ),)
                ],
              ),
            ),
          ),
        Padding(
            padding: const EdgeInsets.fromLTRB(5, 1, 5, 1),
            child: Container(
              height: 180,
              width: 400,
              child: ListView(
                physics: BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                children: [
                  doctorList(
                      distance: "130m Away",
                      image: "lib/icons/male-doctor.png",
                      maintext: "Dr. Marcus Horizon",
                      numRating: "4.7",
                      subtext: "Chardiologist"),
                  doctorList(
                      distance: "130m Away",
                      image: "lib/icons/docto3.png",
                      maintext: "Dr. Maria Elena",
                      numRating: "4.6",
                      subtext: "Psychologist"),
                  doctorList(
                      distance: "2km away",
                      image: "lib/icons/doctor2.png",
                      maintext: "Dr. Stevi Jessi",
                      numRating: "4.8",
                      subtext: "Orthopedist"),
                ],
              ),
            ),   ),
           SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Top Blogs",
                  style: GoogleFonts.inter(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color.fromARGB(255, 46, 46, 46),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.pushReplacement(
                        context,
                        PageTransition(
                            type: PageTransitionType.rightToLeft,
                            child: articlePage()));
                  },
                  child: Text(
                    "See all",
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      color:Color(0xFF010043),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          //Article banner here import from widget>article
          article(
              image: "images/article1.png",
              dateText: "Jun 10, 2021 ",
              duration: "5min read",
              mainText:
              "The 25 Healthiest Fruits You Can Eat,\nAccording to a Nutritionist"),




        ]),
      ),
    );
  }
}
