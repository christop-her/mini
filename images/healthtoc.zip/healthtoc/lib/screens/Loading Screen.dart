import 'package:flutter/material.dart';
import 'package:healthtoc/screens/Home.dart';
import 'package:provider/provider.dart';

import '../Models/Top dotors.dart';
import '../Screens api/BannerApi.dart';
import '../Screens api/TopDoctors.dart';
import '../Test/Provider Class.dart';
import '../Test/second screen.dart';

class loading extends StatefulWidget {
  const loading({super.key});

  @override
  State<loading> createState() => _loadingState();
}
class _loadingState extends State<loading> {
  Dashprovider
      () async {
    Provider.of<BannerApi>(context, listen: false).TopBanner();
    Provider.of<BannerApi>(context, listen: false).TopBanner();
    Provider.of<BannerApi>(context, listen: false).TopBanner();
    Provider.of<MyTopDoctors>(context, listen: false).getTrendingProperytiesItems();
    Provider.of<BannerApi>(context, listen: false).TopBanner();
    await Provider.of<UserProvider>(context, listen: false).fetchUser();
    Navigator.push(
      context, MaterialPageRoute(builder: (context) => Homepage()), );
  }
  @override
  void initState() {

    Dashprovider();
    // TODO: implement initState
    super.initState();
  }
  Widget build(BuildContext context) {
    return Center(
      child: CircularProgressIndicator(),
    );
  }
}
