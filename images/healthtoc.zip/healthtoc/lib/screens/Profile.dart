import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';

import '../auth/login.dart';
import '../widget/profile list.dart';


class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  File? _image;
  final picker = ImagePicker();
  String name ='User';

  getFromPhone() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {

      name =   preferences.getString('mynamed').toString() ;
    });
    try {
      return preferences.getString('mynamed');
    } catch (e) {
      print(e.toString());
    }
  }
  Future<void> _pickImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
      await _uploadImage();
    }
  }

  Future<void> _uploadImage() async {
    if (_image != null) {
      final user = FirebaseAuth.instance.currentUser;
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('profile_images')
          .child('${user?.uid}.jpg');

      await storageRef.putFile(_image!);
      String downloadURL = await storageRef.getDownloadURL();

      // Save the image URL to Firestore
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user?.uid)
          .update({'profileImage': downloadURL});
    }
  }

  @override
  @override
  void initState() {
    getFromPhone();
    // TODO: implement initState
    super.initState();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF010043),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 50,
            ),
            Center(
              child: Stack(
                children: [
                  const SizedBox(
                    height: 50,
                  ),
                  Container(
                    width: 110,
                    height: 110,
                    decoration: BoxDecoration(
                      border: Border.all(width: 4, color: Colors.white),
                      boxShadow: [
                        BoxShadow(
                          spreadRadius: 2,
                          blurRadius: 10,
                          color: Colors.black.withOpacity(0.1),
                        ),
                      ],
                      shape: BoxShape.circle,
                    ),
                    child: FutureBuilder<DocumentSnapshot>(
                      future: FirebaseFirestore.instance
                          .collection('users')
                          .doc(FirebaseAuth.instance.currentUser?.uid)
                          .get(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const CircularProgressIndicator();
                        }
                        if (snapshot.hasError) {
                          return const Icon(Icons.person,color: Colors.white,size: 36,);
                        }
                        final data = snapshot.data?.data() as Map<String, dynamic>?;
                        final imageUrl = data?['profileImage'];
                        return imageUrl != null
                            ? ClipOval(
                          child: Image.network(
                            imageUrl,
                            fit: BoxFit.cover,
                            width: 110,
                            height: 110,
                          ),
                        )
                            : const Icon(
                          Icons.person,
                          size: 70,
                          color: Colors.white,
                        );
                      },
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: GestureDetector(
                      onTap: _pickImage,
                      child: Container(
                        height: 40, // Larger camera icon
                        width: 40,  // Larger camera icon
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(width: 2, color: Colors.white),
                          color: Colors.white,
                        ),
                        child: const Icon(
                          Icons.camera_alt,
                          size: 20, // Adjust the size as needed
                          color: Color(0xFF010043),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Hello,${name??'User'}, ",
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 30,
            ),
            const SizedBox(
              height: 50,
            ),
            Container(
              height: 550,
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
              child: Column(
                children: [
                  const SizedBox(
                    height: 50,
                  ),
                  profile_list(
                    image: "lib/icons/heart2.png",
                    title: "My Saved",
                    color: Colors.black87,
                  ),
                  const Padding(
                    padding:
                    EdgeInsets.symmetric(horizontal: 25, vertical: 10),
                    child: Divider(),
                  ),
                  profile_list(
                    image: "lib/icons/appoint.png",
                    title: "Appointmnet",
                    color: Colors.black87,
                  ),
                  const Padding(
                    padding:
                    EdgeInsets.symmetric(horizontal: 25, vertical: 10),
                    child: Divider(),
                  ),
                  profile_list(
                    image: "lib/icons/appoint.png",
                    title: "FAQs",
                    color: Colors.black87,
                  ),
                  const Padding(
                    padding:
                    EdgeInsets.symmetric(horizontal: 25, vertical: 10),
                    child: Divider(),
                  ),
                  profile_list(
                    image: "lib/icons/pay.png",
                    title: "Payment Method",
                    color: Colors.black87,
                  ),
                  const Padding(
                    padding:
                    EdgeInsets.symmetric(horizontal: 25, vertical: 10),
                    child: Divider(),
                  ),
                  GestureDetector(
                    onTap: () {
                    //  Navigator.of(context).pop(); // Close the dialog
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => loginpage()));
                    },
                    child: profile_list(
                      image: "lib/icons/logout.png",
                      title: "Log out",
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
