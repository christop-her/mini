import 'package:flutter/material.dart';

class shedule_screen extends StatefulWidget {
  const shedule_screen({super.key});

  @override
  State<shedule_screen> createState() => _shedule_screenState();
}

class _shedule_screenState extends State<shedule_screen> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
