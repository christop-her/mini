import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'Fake server.dart';
class UserProvider with ChangeNotifier {
  UserModel? _user;
  UserModel? get user => _user;
  Future<void> fetchUser() async {
    final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/photos/1'));
    if (response.statusCode == 200) { _user = UserModel.fromJson(json.decode(response.body));
    notifyListeners();
    } else {
      throw Exception('Failed to load user');
    }
  }
}