import 'package:flutter/material.dart';
import 'package:healthtoc/Test/second%20screen.dart';
import 'package:provider/provider.dart';

import 'Provider Class.dart';

class FirstPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('First Page')), body: Center(
      child: ElevatedButton(
        onPressed: () async {
          await Provider.of<UserProvider>(context, listen: false).fetchUser();
          Navigator.push(
            context, MaterialPageRoute(builder: (context) => SecondPage()), );
        }, child: Text('Fetch Data and Navigate'), ), ), );
  }
}