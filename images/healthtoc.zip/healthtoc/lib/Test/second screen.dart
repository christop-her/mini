import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'Provider Class.dart';

class SecondPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserProvider>(context).user;
    return Scaffold(
      appBar: AppBar(title: Text('Second Page')), body: user == null
        ? Center(child: CircularProgressIndicator())
        : Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center, children: [
        Text('Name: '), Text('Email: '), ], ), ), );
  }
}