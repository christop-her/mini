class UserModel {
  final String image;
  final String link;
  final String body;
  final String more;
  UserModel({required this.image, required this.link, required this.body, required this.more});
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      image: json['image'],
      link: json['link'],
      body: json['body'],
      more: json['more'], );
  }
}