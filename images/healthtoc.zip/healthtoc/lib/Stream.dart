import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class DisplayPage extends StatefulWidget {
  @override
  _DisplayPageState createState() => _DisplayPageState();
}

class _DisplayPageState extends State<DisplayPage> {
  final Stream<String> _dataStream = Stream.periodic(Duration(seconds: 5)).asyncMap((_) => fetchData());

  static Future<String> fetchData() async {
    final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/photos/1'));
    if (response.statusCode == 200) {
      return response.body;
    } else {
      throw Exception('Failed to load data');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Display Image and Text'),
      ),
      body: StreamBuilder<String>(
        stream: _dataStream,
        builder: (context, snapshot) {
          String imageUrl = 'https://via.placeholder.com/150'; // Placeholder image URL
          String text = 'Placeholder text'; // Placeholder text

          if (snapshot.hasData) {
            final data = json.decode(snapshot.data!);
            imageUrl = data['url']??'https://www.sciencealert.com/images/articles/processed/cutedog_1024.jpg';
            text = data['title']??'Wrong image above';
          }

          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.network(imageUrl),
                SizedBox(height: 20),
                Text(
                  text,
                  style: TextStyle(fontSize: 20),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
