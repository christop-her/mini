import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:path_provider/path_provider.dart';


class FirebaseDatabase with ChangeNotifier {

  Future<String?> doctor(String documentId, String fieldName) async {
    try {
      DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
      await FirebaseFirestore.instance.collection('users').doc('').get();

      if (documentSnapshot.exists) {
        // Check if the document exists
        dynamic fieldValue = documentSnapshot.data()?[fieldName];
        if (fieldValue != null) {
          // Check if the field exists

          return fieldValue.toString();

        }
      }

      return null; // Return null if the document or field doesn't exist
    } catch (e) {
      print('Error getting field value: $e');
      return null;
    }
  }


}